# Serverless Code Repository

This [module](https://www.terraform.io/docs/modules/index.html) creates a private S3 bucket that can be used as a serverless code repository.
