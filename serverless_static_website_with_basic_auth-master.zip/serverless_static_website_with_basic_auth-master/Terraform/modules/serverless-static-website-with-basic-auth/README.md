# Serverless Static Website with Basic Authentication


This [module](https://www.terraform.io/docs/modules/index.html) creates a serverless static website with basic auth in AWS.

All documentation can also be found on [https://github.com/dumrauf/serverless_static_website_with_basic_auth](https://github.com/dumrauf/serverless_static_website_with_basic_auth).